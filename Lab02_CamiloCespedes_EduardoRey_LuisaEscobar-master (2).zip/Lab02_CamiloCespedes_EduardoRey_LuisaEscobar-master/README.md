# Lab02_CamiloCespedes_EduardoRey_LuisaEscobar
Desarrollo de un Software para la simulación de propagación del covid-19 en una población (datos no reales)
